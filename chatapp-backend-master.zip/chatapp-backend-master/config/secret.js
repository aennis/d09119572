module.exports = {
  url: '',
  secret: ''
};
